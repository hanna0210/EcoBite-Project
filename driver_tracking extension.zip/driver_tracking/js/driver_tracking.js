$(function () {
    "use strict";

    var firestoreDB;
    var defaultProject;
    let map;
    let driverLocationMarker = [];
    let driverLocationMarkerIds = [];
    let markerIcon =
        "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png";

    //
    function loadMapView() {
        map = new google.maps.Map(document.getElementById("map"), {
            center: { lat: 0.0, lng: 0.0 },
            zoom: 2
        });
    }

    //
    livewire.on("loadMap", data => {
        //
        markerIcon = {
            url: data,
            // This marker is 20 pixels wide by 32 pixels high.
            size: new google.maps.Size(40, 40),
            // The origin for this image is (0, 0).
            origin: new google.maps.Point(0, 0),
            // The anchor for this image is the base of the flagpole at (0, 32).
            anchor: new google.maps.Point(0, 40)
        };

        //
        loadMapView();
    });

    //
    livewire.on("authenticateUser", data => {

        //
        var firebaseConfig = {
            apiKey: "" + data[0] + "",
            projectId: "" + data[1] + "",
            messagingSenderId: "" + data[2] + "",
            appId: "" + data[3] + "",
        };
        // Initialize Firebase
        defaultProject = firebase.initializeApp(firebaseConfig, "driverTracking");
        //
        firebase.auth(defaultProject)
            .signInWithCustomToken(data[4])
            .then(userCredential => {
                // Signed in
                var user = userCredential.user;

                firestoreDB = defaultProject.firestore();
                // ...
                console.log("Authenticated");
            })
            .catch(error => {
                var errorCode = error.code;
                var errorMessage = error.message;
                // ...
                alert("Authentication failed:: " + errorCode + " " + errorMessage + " ");
            });
    });

    //
    livewire.on("loadDriversOnMap", data => {
        //
        driverLocationMarker.forEach(marker => {
            marker.setMap(null);
        });
        driverLocationMarkerIds = [];
        driverLocationMarker = [];

        data.forEach(driver => {
            listenToDriverNodeOnFCM(driver);
        });
    });

    //listen to driver locations on firebase
    function listenToDriverNodeOnFCM(driver) {
        //
        firestoreDB
            .collection("drivers")
            .doc("" + driver["id"] + "")
            .onSnapshot(doc => {
                //
                let driverLocationData = doc.data();

                if (driverLocationData) {
                    //
                    addMarker(
                        {
                            lat: driverLocationData.lat,
                            lng: driverLocationData.long
                        },
                        driver
                    );
                }
            });
    }

    //
    function addMarker(location, driver) {
        // Add the marker at the clicked location, and add the next-available label
        // from the array of alphabetical characters.
        //
        const driverId = driver["id"];
        const driverName = driver["name"];
        const driverPhone = driver["phone"];
        const driverPhoto = driver["photo"];
        const driverIsOnline = driver["is_online"];
        const driverTotalAssignedOrders = driver["currently_assigned_orders_count"];

        if (!driverLocationMarkerIds.includes(driverId)) {
            //
            const marker = new google.maps.Marker({
                position: location,
                icon: markerIcon,
                map: map
            });




            var statusTag = "<div class='w-4 h-2 p-2 rounded bg-red-500'></div>";
            if (driverIsOnline) {
                statusTag = "<div class='w-4 h-2 p-2 rounded bg-green-500'></div>";
            }

            //infowindow
            const infoContent = document.getElementById("infoContent");

            // Update elements INSIDE #infoContent
            infoContent.querySelector("#driverPhoto").src = driverPhoto;
            infoContent.querySelector("#driverName").textContent = driverName;
            infoContent.querySelector("#driverPhone").textContent = driverPhone;
            infoContent.querySelector("#driverPhone").href = `tel:${driverPhone}`;
            infoContent.querySelector("#statusTag").innerHTML = statusTag;

            // assignedOrderInfo
            const assignedOrderInfoDiv = infoContent.querySelector("#assignedOrderInfo");
            if (driverTotalAssignedOrders <= 0) {
                assignedOrderInfoDiv.style.display = "none";
            } else {
                assignedOrderInfoDiv.style.display = "block";
                // assigedOrdersTotalCount
                infoContent.querySelector("#assigedOrdersTotalCount").textContent = driverTotalAssignedOrders;
                // viewAssigedOrdersLink
                const baseLink = infoContent.querySelector("#orderHerfLink").textContent;
                const ordersLink = baseLink + driverName + "";
                infoContent.querySelector("#viewAssigedOrdersLink").href = ordersLink;
                infoContent.querySelector("#viewAssigedOrdersLink").target = "__blank";
            }

            //reget the div html
            const infoWindowContent = document.getElementById("infoContent").innerHTML;
            const infoWindow = new google.maps.InfoWindow({
                content: `<div style='display: block;'>${infoWindowContent}</div>`,
                // width: 500,
            });

            marker.addListener("click", () => {
                infoWindow.open({
                    anchor: marker,
                    map,
                    shouldFocus: true
                });
            });

            //
            driverLocationMarkerIds.push(driverId);
            driverLocationMarker.push(marker);
        }
        //marker already exists, so just update the location
        else {
            let driverIdIndex = driverLocationMarkerIds.indexOf(driverId);
            driverLocationMarker[driverIdIndex].setPosition(location);
        }
    }
});
